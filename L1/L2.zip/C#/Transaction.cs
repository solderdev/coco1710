using System;

namespace C_
{
    public class Transaction
    {
        public string From {get;set;}
        public string To {get;set;}

        public long Amount {get;set;}

        public long Time {get;set;}
    }
}